<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <title>Forgot Password</title>
    <!-- Favicon-->
    <link rel="icon" href="../../favicon.ico" type="image/x-icon">

    <!-- Google Fonts -->
   <link href="<?php echo site_url('assets/fonts/font.css');?>"  rel="stylesheet" type="text/css">
    <!-- <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" type="text/css"> -->

    <!-- Bootstrap Core Css -->
    <link href="<?php echo site_url('assets/plugins/bootstrap/css/bootstrap.css');?>" rel="stylesheet">

    <!-- Waves Effect Css -->
    <link href="<?php echo site_url('assets/plugins/node-waves/waves.css');?>" rel="stylesheet" />

    <!-- Animation Css -->
    <link href="<?php echo site_url('assets/plugins/animate-css/animate.css');?>" rel="stylesheet" />

    <!-- Custom Css -->
    <link href="<?php echo site_url('assets/css/style.css');?>" rel="stylesheet">
    <link href="<?php echo site_url('assets/css/mycss.css');?>" rel="stylesheet">
</head>

<body class="fp-page">
    <div class="fp-box">
        <div class="logo">
            <a href="javascript:void(0);">ICTC<b>Report</b></a>
            <!-- <small>Admin BootStrap Based - Material Design</small> -->
        </div>
        <div class="card">
            <div class="body">
                    <form action="<?php echo site_url('Login/new_password');?>" method="POST"> 
                    <?php  if($this->session->flashdata('change')){ ?>
                    <div class="alert">
                        <?php echo "<script>alert('password change successfully');Window.location('Login/');</script>";?>
                    </div>
                    <?php } ?>
                    <!-- open otp window -->
                    <div class="msg">
                        Create your new password used to login. We'll send you an email with your username and a
                        link to reset your password.
                    </div>
                   <div class="input-group">
                        <span class="input-group-addon">
                            <i class="material-icons">gavel</i>
                        </span>
                        <div class="form-line">
                            <input type="password" class="form-control" name="newpass" placeholder="Enter Your New Password">
                        </div>
                        <span class="error"><?php echo form_error('newpass'); ?></span>
                    </div>

                    <div class="input-group">
                        <span class="input-group-addon">
                            <i class="material-icons">gavel</i>
                        </span>
                        <div class="form-line">
                            <input type="password" class="form-control" name="cnfmpass" placeholder="Enter Your Confirm Password">
                        </div>
                        <span class="error"><?php echo form_error('cnfmpass'); ?></span>
                    </div>
                    <input class="btn btn-block btn-lg bg-pink waves-effect" name="btnnewpass" type="submit" value="Create a New Password">
                    <div class="row m-t-20 m-b--5 align-center">
                        <a href="<?php echo site_url('Login/'); ?>">Cancel</a>
                    </div>
                </form>
        </div>
    </div>

    <!-- Jquery Core Js -->
    <script src="<?php echo site_url('plugins/jquery/jquery.min.js');?>"></script>

<!-- Bootstrap Core Js -->
<script src="<?php echo site_url('plugins/bootstrap/js/bootstrap.js');?>"></script>

<!-- Waves Effect Plugin Js -->
<script src="<?php echo site_url('plugins/node-waves/waves.js');?>"></script>

<!-- Validation Plugin Js -->
<!-- <script src="<?php //echo site_url('../plugins/jquery-validation/jquery.validate.js');?>"></script> -->

<!-- Custom Js -->
<script src="<?php echo site_url('js/admin.js');?>"></script>
<script src="<?php echo site_url('js/pages/examples/sign-up.js');?>"></script>
</body>

</html>
