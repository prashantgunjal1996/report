<section>
        <!-- Left Sidebar -->
        <aside id="leftsidebar" class="sidebar">
            <!-- User Info -->
            <div class="user-info">
                
                <div class="info-container">
                    <div class="name" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><?=$this->session->userdata('firstname'); ?></div>
                    <div class="email"><?=$this->session->userdata('email'); ?></div>
                    <div class="btn-group user-helper-dropdown">
                        <i class="material-icons" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">keyboard_arrow_down</i>
                        <ul class="dropdown-menu pull-right">
                            <li role="separator" class="divider"></li>
                            <li><a href="<?php echo site_url('ictc/logout/') ?>"><i class="material-icons">input</i>Sign Out</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <!-- #User Info -->
  <!-- Menu -->
  <div class="menu">
                <ul class="list">
                    <li class="header">MAIN NAVIGATION</li>
                    <li class="active">
                        <a href="<?php echo site_url('ictc/') ?>"   >
                            <i class="material-icons" >home</i>
                            <span>Home</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo site_url('ictc/manage') ?>">
                            <i class="material-icons">text_fields</i>
                            <span>ICTC profile</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo site_url('ictc/info_manage') ?>">
                            <i class="material-icons">layers</i>
                            <span>Personal Information</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo site_url('Report/manage_report') ?>">
                            <i class="material-icons">layers</i>
                            <span>Generate Report</span>
                        </a>
                    </li>

                </ul>
            </div>
            <div class="legal">
                 <div class="copyright">
                     &copy;<a href="javascript:void(0);">Prashant Gunjal - 7840966307</a>.
                 </div>
                 <div class="version">
                     &copy;<b>prashantgunjal228@gmail.com</b> 
                 </div>
             </div>
            <!-- #Menu -->
        </aside>
        
 <!-- #Footer -->

 <!-- Jquery Core Js -->
 <script src="<?php echo site_url('assets/plugins/jquery/jquery.min.js'); ?>"></script>

 <!-- Bootstrap Core Js -->
 <script src="<?php echo site_url('assets/plugins/bootstrap/js/bootstrap.js'); ?>"></script>

 <!-- Select Plugin Js -->
 <script src="<?php echo site_url('assets/plugins/bootstrap-select/js/bootstrap-select.js'); ?>"></script>

 <!-- Slimscroll Plugin Js -->
 <script src="<?php echo site_url('assets/plugins/jquery-slimscroll/jquery.slimscroll.js'); ?>"></script>
    <!-- Bootstrap Notify Plugin Js -->
 <script src="<?php echo site_url('assets/plugins/bootstrap-notify/bootstrap-notify.js');?>"></script>

 <!-- Jquery Validation Plugin Css -->
 <script src="<?php echo site_url('assets/plugins/jquery-validation/jquery.validate.js'); ?>"></script>

 <!-- Custom Js -->
 <script src="<?php echo site_url('assets/js/admin.js'); ?>"></script>

 <script src="<?php echo site_url('assets/js/pages/forms/form-validation.js'); ?>"></script>
 <!-- Waves Effect Plugin Js -->
 <script src="<?php echo site_url('assets/plugins/node-waves/waves.js'); ?>"></script>

 <!-- Jquery CountTo Plugin Js -->
 <script src="<?php echo site_url('assets/plugins/jquery-countto/jquery.countTo.js'); ?>"></script>

 <!-- Morris Plugin Js -->
 <script src="<?php echo site_url('assets/plugins/raphael/raphael.min.js'); ?>"></script>

 <script src="<?php echo site_url('assets/plugins/morrisjs/morris.js'); ?>"></script>

 <!-- SweetAlert Plugin Js -->

<script src="<?php echo site_url('assets/js/pages/ui/dialogs.js');?>"></script>

 <!-- Sparkline Chart Plugin Js -->
<script src="<?php echo site_url('assets/plugins/jquery-sparkline/jquery.sparkline.js'); ?>"></script>

 <!-- Custom Js -->
<script src="<?php echo site_url('assets/js/admin.js'); ?>"></script>
<script src="<?php echo site_url('assets/js/pages/index.js'); ?>"></script>

 
<!-- form Wizard -->
<script src="<?php echo site_url('assets/plugins/jquery-steps/jquery.steps.js');?>"></script>
<script src="<?php echo site_url('assets/js/pages/forms/form-wizard.js'); ?>"></script>
<script src="<?php echo site_url('assets/plugins/jquery-datatable/jquery.dataTables.js'); ?>"></script>



 <!-- Demo Js -->
 <script src="<?php echo site_url('assets/js/demo.js'); ?>"></script>
        <!-- #END# Left Sidebar -->
    </section>