<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <title>Forgot Password</title>
    <!-- Favicon-->
  <!--   <link rel="icon" href="../../favicon.ico" type="image/x-icon">
 -->
    <!-- Google Fonts -->
    <link href="<?php echo site_url('assets/fonts/font.css');?>"  rel="stylesheet" type="text/css">
    <!-- <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" type="text/css"> -->

    <!-- Bootstrap Core Css -->
    <link href="<?php echo site_url('assets/plugins/bootstrap/css/bootstrap.css');?>" rel="stylesheet">

    <!-- Waves Effect Css -->
    <link href="<?php echo site_url('assets/plugins/node-waves/waves.css');?>" rel="stylesheet" />

    <!-- Animation Css -->
    <link href="<?php echo site_url('assets/plugins/animate-css/animate.css');?>" rel="stylesheet" />

    <!-- Custom Css -->
    <link href="<?php echo site_url('assets/css/style.css');?>" rel="stylesheet">
    <link href="<?php echo site_url('assets/css/mycss.css');?>" rel="stylesheet">
</head>

<body class="fp-page">
    <div class="fp-box">
        <div class="logo">
            <a href="javascript:void(0);">ICTC<b>Report</b></a>
            <!-- <small>Admin BootStrap Based - Material Design</small> -->
        </div>
        <div class="card">
            <div class="body">
                    <!-- <?php 
                    //if($this->session->flashdata('error'))
                    { ?>
                    <div class="alert alert-danger">
                        <?php // echo $this->session->flashdata('error'); ?>
                    </div>
                    <?php }  ?>  -->  
                    
                    <!-- open otp window -->
                    <?php if($this->session->flashdata('success')) { ?> 
                       <form action="<?php echo site_url('Login/otp_verification');?>" method="POST">
                        <?php if($this->session->flashdata('otp_error')) { ?>
                        <div class="alert">
                            <?php echo "<script>alert('Please Enter OTP');</script>"; ?>
                        </div>
                        <?php } if($this->session->flashdata('unverify')) { ?>
                              <div class="alert">
                                <?php echo "<script>alert('OTP not match');</script>"; ?>
                              </div>
                             <?php } if($this->session->flashdata('match')) { ?>
                              <div class="alert">
                                <?php echo "<script>alert('OTP Match Successfully');</script>"; ?>
                              </div>
                             <?php } ?> 
                            <div class="input-group">
                                <span class="input-group-addon">
                                    <i class="material-icons">email</i>
                                </span>
                                <div class="form-line">
                                    <input type="text" class="form-control" name="otp" placeholder="OTP">
                                </div>
                                <span class="error"><?php echo form_error('otp'); ?></span>
                            </div>
                            <input class="btn btn-block btn-lg bg-pink waves-effect" name="btnotp" type="submit" value="Enter Otp">
                             <div class="row m-t-20 m-b--5 align-center">
                                <a href="<?php echo site_url('Login/'); ?>">Cancel</a>
                            </div>
                               <!-- close otp window -->
                        </form>
                 <?php } else {  ?>
                <form id="<?php echo site_url('Login/resetpassword');?>" method="POST">
                    <div class="msg">
                        Enter your email address that you used to register. We'll send you an email with your username and a
                        link to reset your password.
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon">
                            <i class="material-icons">email</i>
                        </span>
                        <div class="form-line">
                            <input type="email" class="form-control" name="email" placeholder="Email">
                        </div>
                        <span class="error"><?php echo form_error('email'); ?></span>
                    </div>
                    <button class="btn btn-block btn-lg bg-pink waves-effect" data-type="basic" name="reset" type="submit">SEND OTP</button>
                    <div class="row m-t-20 m-b--5 align-center">
                        <a href="<?php echo site_url('Login/'); ?>">Sign In!</a>
                    </div>
                 </form>
                  <?php }?> 
            </div>
        </div>
    </div>

    <!-- Jquery Core Js -->
    <script src="<?php echo site_url('plugins/jquery/jquery.min.js');?>"></script>

<!-- Bootstrap Core Js -->
<script src="<?php echo site_url('plugins/bootstrap/js/bootstrap.js');?>"></script>

<!-- Waves Effect Plugin Js -->
<script src="<?php echo site_url('plugins/node-waves/waves.js');?>"></script>

<!-- Validation Plugin Js -->
<!-- <script src="<?php //echo site_url('../plugins/jquery-validation/jquery.validate.js');?>"></script> -->

<!-- Custom Js -->
<script src="<?php echo site_url('js/admin.js');?>"></script>
<script src="<?php echo site_url('js/pages/examples/sign-up.js');?>"></script>
</body>

</html>
