<?php
$this->load->view('comman_file/header.php');
$this->load->view('comman_file/sidebar.php'); ?>

    <!-- <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.1/jquery.js"></script>
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.7.2/jquery-ui.min.js"></script> -->
     <script src="<?php echo site_url('assets/js/date.js'); ?>"></script>
     <script src="<?php echo site_url('assets/js/date_ajax.js'); ?>"></script>
      <script src="<?php // echo site_url('assets/js/jquery-ui.css'); ?>"></script>
    <link rel="stylesheet" type="text/css" media="screen" href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.7.2/themes/base/jquery-ui.css">
    <script type="text/javascript">
       var j =  $.noConflict();
        j(function() {
            j('.date-picker').datepicker( {
            changeMonth: true,
            changeYear: true,
            showButtonPanel: true,
            dateFormat: 'MM yy',
            onClose: function(dateText, inst) { 
                j(this).datepicker('setDate', new Date(inst.selectedYear, inst.selectedMonth, 1));
            }
            });
        });
    </script>
    <style>
    .ui-datepicker-calendar {
        display: none;
    }
    </style>

 <section class="content">
        <div class="container-fluid">
            <div class="block-header">
                <h3>Generate Report</h3>
            </div>
            <!-- Example -->
            <div class="row clearfix">
                <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>Progress Report</h2>
                        </div>
                        <div class="body">
                            <div class="row clearfix">
                                <form action = "<?php echo site_url('Report/generate_report/'.$id); ?>" method="POST">
                                    <div class="form-line">
                                        <div class="col-md-6">
                                            <label for="startDate">Date :</label>
                                            <input name="startDate" id="startDate" name="startDate" placeholder = "Select Report Period" class="date-picker"
                                            value="<?php if(isset($update_report)){ echo isset($update_report)?$update_report->reporting_period:'';}else echo set_value('startDate');?>" />
                                        </div>
                                         </div>
                                        <span class="error"><?php echo form_error('report_date'); ?></span>
                                  </div>
                                    <div class="row clearfix">
                                        <div class="col-md-6">
                                            <div class="form-line">
                                                <label for=""> ANC :</label>
                                                <input type="text" class="form-control" id="anc" name="anc" placeholder="No Of ANC" 
                                                value="<?php if(isset($update_report)){ echo isset($update_report)?$update_report->anc:'';}else echo set_value('anc');?>">
                                            </div>
                                            <span class="error"><?php echo form_error('anc'); ?></span>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-line">
                                                <label for="" style="color: red;"> Detected ANC :</label>
                                                <input type="text" class="form-control" id="p_anc" name="p_anc" placeholder="No Of Positive ANC"
                                                value="<?php if(isset($update_report)) { echo ($update_report)?$update_report->male_detect:''; } else echo set_value('p_anc'); ?>">
                                            </div>
                                            <span class="error"><?php echo form_error('p_anc'); ?></span>
                                        </div>
                                    </div>
                                    <div class="row clearfix">
                                        <div class="col-md-6">
                                            <div class="form-line">
                                                <label for=""> Male :</label>
                                                <input type="text" class="form-control" id="male" name="male" placeholder="No Of Male Patient"
                                                value="<?php if(isset($update_report)){ echo($update_report)?$update_report->male:''; }else echo set_value('male'); ?>">
                                            </div>
                                            <span class="error"><?php echo form_error('male'); ?></span>

                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-line">
                                                <label for="" style="color: red;"> Detected Male  :</label>
                                                <input type="text" class="form-control" id="p_male" name="p_male" placeholder="No Of Positive Male"
                                                value="<?php if(isset($update_report)){ echo($update_report)?$update_report->male_detect:''; }else echo set_value('p_male'); ?>">
                                            </div>
                                             <span class="error"><?php echo form_error('p_male'); ?></span>
                                        </div>
                                    </div>

                                    <div class="row clearfix">
                                        <div class="col-md-6">
                                            <div class="form-line">
                                                <label for=""> Female:</label>
                                                <input type="text" class="form-control" id="female" name="female" placeholder="No Of Female Patient"
                                                value="<?php if(isset($update_report)){ echo($update_report)?$update_report->female:''; }else echo set_value('female'); ?>">
                                            </div>
                                            <span class="error"><?php echo form_error('female'); ?></span>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-line">
                                                <label for="" style="color: red;"> Detected Female :</label>
                                                <input type="text" class="form-control" id="p_female" name="p_female" placeholder="No Of Positive Females"
                                                value="<?php if(isset($update_report)){ echo($update_report)?$update_report->female_detect:''; }else echo set_value('p_female'); ?>">
                                            </div>
                                            <span class="error"><?php echo form_error('p_female'); ?></span>
                                        </div>
                                    </div>
                                   <div class="row clearfix">
                                        <div class="col-md-6">
                                            <div class="form-line">
                                                <label for=""> Total Male & Female :</label>
                                                <input type="text" readonly class="form-control" id="total_mf" name="total_mf" placeholder="No Of Male"
                                                value="<?php if(isset($update_report)){ echo($update_report)?$update_report->male_female_total:''; }else echo set_value('total_mf'); ?>">
                                            </div>
                                            <span class="error"><?php echo form_error('total_mf'); ?></span>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-line">
                                                <label for="" style="color: red;"> Total Detected Male/Female :</label>
                                                <input type="text" readonly class="form-control" id="total_p_mf" name="total_p_mf" placeholder="Total Positive Patient"
                                                value="<?php if(isset($update_report)){ echo($update_report)?$update_report->detected_mf_total:''; }else echo set_value('total_p_mf'); ?>">
                                            </div>
                                            <span class="error"><?php echo form_error('total_p_mf'); ?></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row clearfix">
                        <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
                        <div class="card">
                            <div class="header">
                                <h2>Stock Report</h2>
                            </div>
                            <div class="body">
                                    <div class="row clearfix">
                                        <div class="col-md-6">
                                            <div class="form-line">
                                                <label for=""> Batch No : :</label>
                                                <input type="text" class="form-control" name="batch" placeholder="Enter Batch No"
                                                value="<?php if(isset($update_report)){ echo($update_report)?$update_report->batchno:''; }if(isset($last_record)) { echo $last_record->batchno;} else echo set_value('batchno'); ?>">
                                            </div>
                                             <span class="error"><?php echo form_error('batch'); ?></span>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-line">
                                                 <label for=""> Expiry Date :</label>
                                                <input type="text" id="" name="exp_date" class="date-picker"  placeholder="Enter Expiry Date"
                                                value="<?php if(isset($update_report)){ echo($update_report)?$update_report->expirydate:''; }if(isset($last_record)) { echo $last_record->expirydate;} else echo set_value('expirydate'); ?>">
                                            </div>
                                             <span class="error"><?php echo form_error('exp'); ?></span>
                                        </div>
                                    </div>

                                    <div class="row clearfix">
                                        <div class="col-md-6">
                                            <div class="form-line">
                                                <label for=""> Opening Stock :</label>
                                                <input type="text"  class="form-control" id="opngstck" name="opngstck" placeholder="Previous month closing stock"
                                                value="<?php if(isset($update_report)){ echo($update_report)?$update_report->openingstock:''; } if(isset($last_record)) {  echo  $last_record->closing;} else echo set_value('opngstck'); ?>">
                                            </div>
                                             <span class="error"><?php echo form_error('opngstck'); ?></span>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-line">
                                                 <label for=""> Consumed :</label>
                                                <input type="text" readonly class="form-control" id="consumed" name="consumed" placeholder="Enter Used kits"
                                                value="<?php if(isset($update_report)){ echo($update_report)?$update_report->consumed:''; }else echo set_value('consumed'); ?>">
                                            </div>
                                             <span class="error"><?php echo form_error('consumed'); ?></span>
                                        </div>
                                    </div>
                                     <div class="row clearfix">
                                        <div class="col-md-6">
                                            <div class="form-line">
                                                <label for=""> Received :</label>
                                                <input type="text" class="form-control" id="received" name="received" placeholder="Enter Received kits"
                                                value="<?php if(isset($update_report)){ echo($update_report)?$update_report->received:''; }else echo set_value('received'); ?>">
                                            </div>
                                            <span class="error"><?php echo form_error('received'); ?></span>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-line">
                                                 <label for=""> Control :</label>
                                                <input type="text" class="form-control" id="control" name="control" placeholder="Control kits"
                                                value="<?php if(isset($update_report)){ echo($update_report)?$update_report->control:''; }else echo set_value('control'); ?>">
                                            </div>
                                             <span class="error"><?php echo form_error('control'); ?></span>
                                        </div>
                                    </div>
                                    <div class="row clearfix">
                                        <div class="col-md-6">
                                            <div class="form-line">
                                                <label for=""> Wastage :</label>
                                                <input type="text" class="form-control" id="wastage" name="wastage" placeholder="Wastage kits"
                                                value="<?php if(isset($update_report)){ echo($update_report)?$update_report->wastage:''; }else echo set_value('wastage'); ?>">
                                            </div>
                                             <span class="error"><?php echo form_error('Wastage'); ?></span>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-line">
                                                 <label for=""> Closing Stock :</label>
                                                <input type="text" class="form-control" id="closing" name="closing" placeholder="Closing Stock"
                                                value="<?php if(isset($update_report)){ echo($update_report)?$update_report->closing:''; }else echo set_value('closing'); ?>">
                                            </div>
                                            <span class="error"><?php echo form_error('closing'); ?></span>
                                        </div>
                                    </div>
                                     <div class="row clearfix">
                                        <div class="col-md-6">
                                            <div class="form-line">
                                                <label for=""> Quantity Intended :</label>
                                                <input type="text" class="form-control" id="qty" name="qty" placeholder="Enter Quantity Intended"
                                                value="<?php if(isset($update_report)){ echo($update_report)?$update_report->qty_intended:''; }else echo set_value('qty'); ?>">
                                            </div>
                                             <span class="error"><?php echo form_error('qty'); ?></span>
                                        </div>

                                         <div class="col-md-6">
                                            <div class="form-line">
                                                <input type="hidden" class="form-control" id="total_stock" name="qty" placeholder="Enter Quantity Intended">
                                            </div>
                                             <span class="error"><?php echo form_error('qty'); ?></span>
                                        </div>
                                    </div>
                                     <div class="row clearfix">
                                        <div class="col-md-6">
                                            <div class="form-line">
                                                <input type="hidden" class="form-control" id="total_use" name="qty" placeholder="Enter Quantity Intended">
                                            </div>
                                        </div>
                                    </div>
                                    <?php if($isedit) { ?> 
                                        <input type="submit" class="btn btn-success waves-effect" name="btnupdate" value="UPDATE"> 
                                        <?php } else { ?>
                                        <input type="submit" class="btn btn-primary waves-effect" name="btnreport" value="Submit"> 
                                        <?php } ?>
                                        <input type="submit"  class="btn btn-secondary waves-effect" value="Cancel">
                                </form>
                                </div>
                            </div>
                        </div>
                        </div>
                </div>
            </div>
        </div>
</section>


<script type="text/javascript">

    $('#female').on('input',function(){
        // store total male and female 
        var male = $("#male").val();
        var female = $("#female").val();
        var total_male = Number(male) + Number(female);
        $('#total_mf').val(total_male);
    
         // store all tested tests
        var anc = $("#anc").val();
        var total_consumed = Number(anc) + Number(total_male);
        $('#consumed').val(total_consumed);

       $('#p_female').on('input',function(){
        // store total positive male and female
        var p_male = $("#p_male").val();
        var p_female = $("#p_female").val();
        let total_positive = Number(p_male) + Number(p_female);
        $('#total_p_mf').val(total_positive);

       $('#received').on('input',function(){
        // store all received and opening stock
            var opening = $("#opngstck").val();
            var received = $("#received").val();
            var total_stock = Number(opening) + Number(received);
            $('#total_stock').val(total_stock);
      

        $('#wastage').on('input',function(){
            // store all control and wasatge and consumed stock
            var control = $("#control").val();
            var wastage = $("#wastage").val();
            var total_used_kit = Number(wastage) + Number(control) + Number(total_consumed);
            $('#total_use').val(total_used_kit);

            // store closing stock
            var closing_stock = Number(total_stock) - Number(total_used_kit);
            // alert();
            $('#closing').val(closing_stock);
        });
        });       
        });
        });
</script>>


