<?php
$this->load->view('comman_file/header.php');
$this->load->view('comman_file/sidebar.php'); ?>

<section class="content">
    <div class="container-fluide">
        <div class="block-header">

            <?php if($this->session->flashdata('delete')){ ?>
                    <div class="alert">
                        <?php echo $this->session->flashdata('delete') ; ?>
                    </div>
                    <?php } if($this->session->flashdata('added'))  { ?>   
                        <div class="alert">
                            <?php echo "<script>alert('Information Added Successfully');window.reload();</script>"; ?></div>
                    <?php }?>
                 <?php if($this->session->flashdata('updated')){ ?>
                    <div class="alert">
                        <?php echo "<script>alert('Record Update Successfully'); window.reload();</script>"; ?>
                    </div>
                    <?php } if($this->session->flashdata('update_error'))  { ?>   
                        <div class="alert">
                            <?php echo "<script>alert('Error While Updating Record');</script>"; ?></div>
                    <?php }?>  

            <div class="col-xs-10 p-b-5">
                <h3> Manage Information</h3>
            </div>
            <div class="col-xs-2 p-b-5">
                <a class="btn btn-block bg-teal waves-effect"  href="<?php echo site_url('ictc/info_manage'); ?>">SHOW</a>
            </div>
            
        </div>
        
        <!-- Basic Validation -->
            <div id="f" class="row clearfix js-sweetalert">
                <div class="col-lg-12 col-md-6 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>Personal Information :</h2>
                        </div>
                        <div class="body">
                             <form action ="<?php echo site_url('Ictc/Personal_info/'.$id);?>" method="POST">
                                <div class="form-group form-float">
                                    <div class="form-line">
                                        <input type="text" class="form-control" name="name" value="<?php if(isset($update_info)){ echo isset($update_info)?$update_info->name:'';}else echo set_value('name');?>" >
                                        <label class="form-label">Your Name :</label> 
                                    </div>
                                     <span class="error"><?php echo form_error('name');?></span>
                                </div>
                                <div class="form-group form-float">
                                    <div class="form-line">
                                        <input type="text" class="form-control" name="email" value="<?php if(isset($update_info)){ echo isset($update_info)?$update_info->email:'';}else echo set_value('email');?>" >
                                        <label class="form-label">Email :</label> 
                                    </div>
                                     <span class="error"><?php echo form_error('email');?></span>
                                </div>
                                <div class="form-group form-float">
                                    <div class="form-line">
                                        <input type="text" class="form-control" name="mobile" value="<?php if(isset($update_info)){ echo isset($update_info)?$update_info->mob:'';}else echo set_value('mobile');?>" >
                                        <label class="form-label">Mobile</label>
                                    </div>
                                    <span class="error"><?php echo form_error('mobile');?></span>
                                </div>
                                <div class="form-group form-float">
                                    <div class="form-line">
                                        <input type="text" class="form-control" name="location" value="<?php if(isset($update_info)){ echo isset($update_info)?$update_info->loc:'';}else echo set_value('location');?>" >
                                        <label class="form-label">ICTC Location</label>
                                    </div>
                                    <span class="error"><?php echo form_error('location');?></span>
                                </div>
                                 <?php if($isedit_info) {  ?>
                                <input type="submit" class="btn btn-primary waves-effect" name="btnupdate" value="Update">
                                 <?php }else { ?>
                                 <input type="Submit" class="btn btn-success waves-effect" name="btnaddinfo" Value="submit">
                                  <?php } ?>
                                <button class="btn btn-secondary waves-effect" onclick=""  type="button">Cancel</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


