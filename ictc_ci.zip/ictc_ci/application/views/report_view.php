<!DOCTYpe html>
<html>

<head>
    <title>ICTC report</title>
    <link rel="stylesheet" href="">
    <link rel="stylesheet" href="<?php echo site_url('assets/css/bootstrap.min.css'); ?>">
    <style>
        tr {
            border: 1px solid #000000;
        }
        
        td {
            border: 1px solid #000000;
        }
        
        .table tr td {
            border: 1px solid #000000;
        }
        
        .table {
            margin-bottom: 0px;
        }
        
        #color {
            background-color: lightgray !important;
            -webkit-print-color-adjust: exact;
        }

        #dark {
            background-color: #000;
        }
        
        @media print {
            #dark {
                background-color: #000 !important;
                -webkit-print-color-adjust: exact;
            }
            
        }
        @media print {
            #printbtn {
                display: none;
            }
        }


    </style>
    
</head>

<body>
   
    <div class="container">
        <div class="col-xs-10 p-b-5">
                
        <div class="form-group form-float">
        <div class="form-line">
            <input type="submit" class="btn btn-primary waves-effect" id="printbtn" onclick="window.print();" value="Print">
        </div>
    </div>
    </div>
        <div id="content" style="padding: 10px;margin-top: 75px; ">
            <table class="table">
                <tr>
                    <td width='15%'><strong>F-ICTC Code</strong></td>
                    <td width='85%'></td>
                </tr>
                <tr>
                    <td colspan="4 "><strong>MOTHLY REPORTING FORMAT : FACILITY INTEGRATED / PPP ICTC</strong></td>
                </tr>
            </table>

            <table class="table ">
                <tr>
                    <td colspan="5 " id="color">
                        <h5 align="center ">SECTION A. IDENTIFICATION</h5>
                    </td>
                </tr>
                <tr>
                    <td><strong>Name Of Center : </strong> </td>
                    <td colspan="2"><?=$data['name'] = $center->name;?></td>
                    <td><strong> TYPE of FICTC</strong></td>
                    <td><strong><?=$data['ictc_type'] =  $center->ictc_type;?></strong> </td>
                </tr>
                <tr>
                    <td colspan="1 ">
                        <strong>Address</strong>
                    </td>
                    <td colspan="4 ">
                       <?= $data['addr'] = $center->addr;?>
                    </td>
                </tr>
                <tr>
                    <td>
                        <strong>Pincode</strong>
                    </td>
                    <td>
                        <strong><?=$data['pin'] = $center->pin;?></strong>
                    </td>
                    <td>
                        <strong>Taluka : </strong>
                        <span><?=$data['tal'] =  $center->tal;?></span>
                    </td>
                    <td>
                        <strong>District : </strong>
                        <span><?=$data['dist'] =  $center->dist;?></span>
                    </td>
                    <td>
                        <strong>State :</strong>
                        <span><?=$data['state'] = $center->state;;?></span>
                    </td>
                </tr>
                <tr>
                    <td><strong>Reporting Period : </strong></td>
                    <td><?= $view->reporting_period;?></td>
                    <!-- <td>YEAR</td> -->
                    <td colspan="4 "></td>
                </tr>
                <tr>
                    <td colspan="2 ">Name of Officer Incharge :</td>
                    <td colspan="3 "><?=$name?></td>
                </tr>
                <tr>
                    <td colspan="2 ">Contact No.</td>
                    <td colspan="3 "><?=$mob?>
                    </td>
                </tr>
                <tr>
                    <td colspan="2 ">Email Addresse</td>
                    <td colspan="3 "><?=$email?></td>
                </tr>
                <tr>
                    <td colspan="2 ">F-ICTC Location</td>
                    <td colspan="3 "><?=$loc?></td>
                </tr>
            </table>

            <table class="table ">
                <tr>
                    <td id="color" colspan="8">
                        <h5 align="center ">SECTION B. BASIC INDICATION</h5>
                    </td>
                </tr>
                <tr>
                    <td id="color" colspan="8 ">
                        <h6 align="center ">1.Progress During the Month</h6>
                    </td>
                </tr>
                <tr>
                    <td width="40% " colspan="1 "></td>
                    <td colspan="3 ">Pregnent Women</td>
                    <td colspan="4 ">General Client</td>
                </tr>
                <tr>
                    <td width=" 30% "></td>
                    <td>ANC</td>
                    <td>DIRECT IN</td>
                    <td>Total</td>
                    <td>Male</td>
                    <td>Female</td>
                    <td>TS/TG</td>
                    <td>Total</td>
                </tr>
                <tr>
                    <td>Total ANC Client</td>
                    <td><?php echo $view->anc;?></td>
                    <td id="dark"></td>
                    <td><?php echo $view->anc;?></td>
                    <td id="dark"></td>
                    <td id="dark"></td>
                    <td id="dark"></td>
                    <td id="dark"></td>
                </tr>
                <tr>
                    <td>No.of Client Provided Pre-test</td>
                    <td><?php echo $view->anc;?></td>
                    <td align="center ">00</td>
                    <td><?php echo $view->anc;?></td>
                    <td><?php echo $view->male;?></td>
                    <td><?php echo $view->female;?></td>
                    <td>00</td>
                    <td><?php echo $view->male_female_total;?></td>
                </tr>
                <tr>
                    <td>No of Client Tested for HIV</td>
                    <td><?php echo $view->anc;?></td>
                    <td align="center ">00</td>
                    <td><?php echo $view->anc;?></td>
                    <td><?php echo $view->male;?></td>
                    <td><?php echo $view->female;?></td>
                    <td>00</td>
                    <td><?php echo $view->male_female_total;?></td>
                </tr>
                <tr>
                    <td>No.of clients provided post-test</td>
                    <td><?php echo $view->anc;?></td>
                    <td align="center ">00</td>
                    <td><?php echo $view->anc;?></td>
                    <td><?php echo $view->male;?></td>
                    <td><?php echo $view->female;?></td>
                    <td>00</td>
                    <td><?php echo $view->male_female_total;?></td>
                </tr>
                <tr>
                    <td>No.of client Detective HIV reactive after </td>
                    <td><?php echo $view->anc_detect;?></td>
                    <td align="center ">00</td>
                    <td><?php echo $view->anc_detect;?></td>
                    <td><?php echo $view->male_detect;?></td>
                    <td><?php echo $view->female_detect;?></td>
                    <td>00</td>
                    <td><?php echo $view->detected_mf_total;?></td>
                </tr>
                <tr>
                    <td>No of client tested for syphills</td>
                    <td><?php echo $view->anc;?></td>
                    <td id="dark"></td>
                    <td><?php echo $view->anc;?></td>
                    <td>--</td>
                    <td id="dark"></td>
                    <td id="dark"></td>
                    <td id="dark"></td>
                </tr>
                <tr>
                    <td>No.of ANC Client for</td>
                    <td>00</td>
                    <td id="dark"></td>
                    <td>00</td>
                    <td>--</td>
                    <td id="dark"></td>
                    <td id="dark"></td>
                    <td id="dark"></td>
                </tr>
            </table>

            <table class="table " style="margin-bottom:0px; ">
                <tr>
                    <td colspan="3 " id="color">
                        <h6 align="center ">2.LINKAGE & REFERRAL</h6>
                    </td>
                </tr>
                <tr>
                    <td width="40% "><strong>Department & Oragnization</strong></td>
                    <td>
                        <strong>In Refferal</strong>
                    </td>
                    <td><strong>Out Refferal</strong></td>
                </tr>
                <tr>
                    <td>OBG / GYN (ANC)
                    </td>
                    <td><?php echo $view->anc;?> </td>
                    <td><?php echo $view->anc_detect;?> </td>
                </tr>
                <tr>
                    <td>Targeted Intervantions NGOs
                    </td>
                    <td>00</td>
                    <td>00</td>
                </tr>
                <tr>
                    <td>Link Workers
                    </td>
                    <td>00</td>
                    <td>00</td>
                </tr>
                <tr>
                    <td>RNTCP
                    </td>
                    <td>00</td>
                    <td>00</td>
                </tr>
                <tr>
                    <td>STI CLINIC
                    </td>
                    <td>00</td>
                    <td>00</td>
                </tr>
                <tr>
                    <td>OTHERS
                    </td>
                    <td><?php echo $view->male_female_total?></td>
                    <td><?php echo $view->detected_mf_total?></td>
                </tr>
            </table>

            <table class="table">
                <tr>
                    <td colspan="11" id="color">
                        <h6 align="center ">3.STOCKS STATUS OF HIV TEST KITS(NUMBER OF TEST)</h6>
                    </td>
                </tr>
                <tr>
                    <td><b>Consumable</b></td>
                    <td><b>Kit Name</b></td>
                    <td><b>Batch No.</b></td>
                    <td><b>Exp.Date</b></td>
                    <td><b>Opning Stock</b></td>
                    <td><b>Consumed</b></td>
                    <td><b>Received</b></td>
                    <td><b>control</b></td>
                    <td><b>Wastage</b></td>
                    <td><b>Clsng Stock</b></td>
                    <td><b>Qty</b></td>
                </tr>
                <tr>
                    <td>Whole Blood</td>
                    <td>Meriscreen</td>
                    <td><?php echo $view->batchno;?></td>
                    <td><?php echo $view->expirydate;?></td>
                    <td><?php echo $view->openingstock;?></td>
                    <td><?php echo $view->consumed;?></td>
                    <td><?php echo $view->received;?></td>
                    <td><?php echo $view->control;?></td>
                    <td><?php echo $view->wastage;?></td>
                    <td><?php echo $view->closing;?></td>
                    <td><?php echo $view->qty_intended;?></td>
                </tr>
                <tr>
                    <td colspan="11 " id="color">
                        <h6 align="center ">SECTION C. STI/RTI MOTHLY INDICATORS</h6>
                    </td>
                </tr>
                <tr>
                    <td><strong>Total TB patient</strong></td>
                    <td><strong>HIV conduct</strong></td>
                    <td colspan='2' style="text-align:center; "><strong>Total</strong></td>
                </tr>
                <tr>
                    <td rowspan="2 ">0</td>
                    <td rowspan="2 " style="text-align:center;">0</td>
                    <td style="text-align:center; " colspan=''>M</td>
                    <td style="text-align:center; " colspan='1'>F</td>
                </tr>
                <tr>

                    <td style="text-align:center; " colspan="1 ">0</td>
                    <td style="text-align:center; " colspan="1 ">0</td>
                </tr>
            </table>


        </div>
    </div>
</body>

</html>

