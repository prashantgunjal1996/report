<?php
$this->load->view('comman_file/header.php');
$this->load->view('comman_file/sidebar.php'); ?>


<section class="content">
    <div class="container-fluide">
        <div class="block-header">

            <?php if($this->session->flashdata('error')){ ?>
                    <div class="alert">
                        <?php echo $this->session->flashdata('error'); ?>
                    </div>
                    <?php } if($this->session->flashdata('add_center'))  { ?>   
                    <div class="alert">
                            <?php echo "<script>alert('Record Added Successfully'); window.reload();</script>"; ?></div>
                    <?php }?> 

            <div class="col-xs-10 p-b-5">
                <h3>Manage Center</h3>
            </div>
            <div class="col-xs-2 p-b-5">
                <a class="btn btn-block bg-pink waves-effect"  href="<?php echo site_url('ictc/add_center'); ?>">ADD</a>
            </div>
            
        </div>
        
           <div id="v" class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>
                                Center Information
                            </h2>
                        </div>
                        <div class="body table-responsive">
                            <table class="table" id="sampleTable">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Center NAME</th>
                                        <th>Type</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $i=1; foreach($records as $record) { ?>
                                    <tr>
                                        <td><?php echo $i++; ?></td>
                                        <td><?php echo $record->name; ?></td>
                                        <td><?php echo $record->ictc_type; ?></td>
                                        <td><a href="<?php echo site_url('ictc/Center') ?>" class="label bg-green"><?php echo $record->status; ?></a> </td>
                                         <td><a id="edit" href="<?php echo site_url('ictc/Manage/'.$record->id); ?>" class="btn btn-warning">EDIT</a> |
                                         <a href="<?php echo site_url('ictc/center_delete/'.$record->id); ?>" class="btn btn-danger">DELETE</a> 
                                        </td>
                                    </tr>
                                <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- #END# 
            Basic Validation -->

    </div>

</section>
<script>
    $('#sampleTable').DataTable();
  </script>


