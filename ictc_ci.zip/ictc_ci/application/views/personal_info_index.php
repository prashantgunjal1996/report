<?php
$this->load->view('comman_file/header.php');
$this->load->view('comman_file/sidebar.php'); ?>


<section class="content">
    <div class="container-fluide">
        <div class="block-header">

            <?php if($this->session->flashdata('delete')){ ?>
                    <div class="alert alert-danger">
                        <?php echo $this->session->flashdata('delete'); ?>
                    </div>
                    <?php } if($this->session->flashdata('add_center'))  { ?>   
                        <div class="alert alert-success">
                            <?php echo $this->session->flashdata('add_center'); ?></div>
                    <?php }?> 

            <div class="col-xs-10 p-b-5">
                <h3>Manage Information</h3>
            </div>
            <div class="col-xs-2 p-b-5">
                <a class="btn btn-block bg-pink waves-effect"  href="<?php echo site_url('ictc/personal_info'); ?>">ADD</a>
            </div>
            
        </div>
        
           <div id="v" class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>
                                Personal Information
                            </h2>
                        </div>
                        <div class="body table-responsive">
                            <table class="table" id="sampleTable">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>NAME</th>
                                        <th>Email</th>
                                        <th>Mobile</th>
                                        <th>Location</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $i=1; foreach($records as $record) { ?>
                                    <tr>
                                        <td><?php echo $i++; ?></td>
                                        <td><?php echo $record->name; ?></td>
                                        <td><?php echo $record->email; ?></td>
                                         <td><?php echo $record->mob;; ?></td>
                                        <td><?php echo $record->loc; ?></td>
                                    
                                        
                                         <td><a id="edit" href="<?php echo site_url('ictc/info_manage/'.$record->id); ?>" class="btn btn-warning">EDIT</a> |
                                         <a  href="<?php echo site_url('ictc/delete/'.$record->id); ?>"  class="btn btn-danger">DELETE</a> 
                                        </td>
                                    </tr>
                                <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- #END# 
            Basic Validation -->

    </div>

</section>
<script>
    $('#sampleTable').DataTable();
  </script>