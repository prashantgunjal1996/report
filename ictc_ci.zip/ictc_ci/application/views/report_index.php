<?php
$this->load->view('comman_file/header.php');
$this->load->view('comman_file/sidebar.php'); ?>


<section class="content">
    <div class="container-fluide">
        <div class="block-header">

            <?php if($this->session->flashdata('report_success')){ ?>
                    <div class="alert">
                        <?php echo "<script>alert('Report Generated Successfully');</script>"; ?>
                    </div>
                    <?php } if($this->session->flashdata('update_report'))  { ?>   
                        <div class="alert ">
                            <?php echo "<script>alert('Report Updated Successfully');</script>"; ?></div>
                    <?php }?> 
                    <?php if($this->session->flashdata('delete_report'))  { ?>   
                        <div class="alert ">
                            <?php echo "<script>alert('Report Deleted Successfully');</script>"; ?></div>
                    <?php }?>

            <div class="col-xs-10 p-b-5">
                <h3>Report Information</h3>
            </div>
            <div class="col-xs-2 p-b-5">
                <a class="btn btn-block bg-pink waves-effect"  href="<?php echo site_url('report/generate_report'); ?>">Create Report</a>
            </div>
            
        </div>
        
           <div id="v" class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            
                        </div>
                        <div class="body table-responsive">
                            <table class="table" id="sampleTable">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Reporting Period</th>
                                       
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $i=1; foreach($reports as $report) { ?>
                                    <tr>
                                        <td><?php echo $i++; ?></td>
                                        <td><?php echo $report->reporting_period; ?></td>
                                      
                                         <td><a id="edit" href="<?php echo site_url('Report/manage_report/'.$report->id); ?>" class="btn btn-warning">EDIT</a> |
                                         <a  href="<?php echo site_url('Report/delete_report/'.$report->id); ?>"  class="btn btn-danger">DELETE</a> |
                                         <a  href="<?php echo site_url('Report/view/'.$report->id); ?>"  class="btn btn-success">VIEW</a>
                                        </td>
                                    </tr>
                                <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- #END# 
            Basic Validation -->

    </div>

</section>
<script>
    $('#sampleTable').DataTable();
  </script>


