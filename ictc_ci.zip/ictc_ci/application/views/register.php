<?php
$this->load->view('comman_file/header.php');
$this->load->view('comman_file/sidebar.php'); ?>


<section class="content">
    <div class="container-fluide">
        <div class="block-header">

            <?php if($this->session->flashdata('error')){ ?>
                    <div class="alert alert-danger">
                        <?php echo $this->session->flashdata('error'); ?>
                    </div>
                    <?php } if($this->session->flashdata('add_center'))  { ?>   
                        <div class="alert">
                            <?php echo "<script>alert('Record Added Successfully');</script>";  ?></div>
                    <?php } ?> 
                    <?php if($this->session->flashdata('update_center'))  { ?>   
                        <div class="alert">
                            <?php echo "<script>alert('Record Updated Successfully');</script>";  ?></div>
                    <?php } ?> 

            <div class="col-xs-10 p-b-5">
                <h3> Manage Center</h3>
            </div>
            <div class="col-xs-2 p-b-5">
                <a class="btn btn-block bg-teal waves-effect"  href="<?php echo site_url('ictc/Manage'); ?>">SHOW</a>
            </div>
            
        </div>
        
        <!-- Basic Validation -->
            <div id="f" class="row clearfix js-sweetalert">
                <div class="col-lg-12 col-md-6 col-sm-12 col-xs-12">
                   
                    <div class="card">
                        <div class="header">
                            <h2>Enter Center Detail :</h2>
                        </div>
                        <div class="body">
                             <form action="<?php echo site_url('ictc/add_center/'.$id);?>" method="POST">
                                <div class="form-group form-float">
                                    <div class="form-line">
                                        <input type="text" class="form-control" name="name" value="<?php if(isset($update)){ echo isset($update)?$update->name:'';}else echo set_value('name');?>" >
                                        <label class="form-label">Name Of Center :</label> 
                                    </div>
                                     <span class="error"><?php echo form_error('name');?></span>
                                </div>
                                <div class="form-group form-float">
                                    <div class="form-line">
                                        <input type="text" class="form-control" name="addr" value="<?php if(isset($update)){ echo isset($update)?$update->addr:'';}else echo set_value('addr');?>" >
                                        <label class="form-label">Addresse</label>
                                    </div>
                                    <span class="error"><?php echo form_error('addr');?></span>
                                </div>
                                <div class="form-group form-float">
                                    <div class="form-line">
                                        <input type="text" class="form-control" name="type" value="<?php if(isset($update)){ echo isset($update)?$update->ictc_type:'';}else echo set_value('ictc_type');?>" >
                                        <label class="form-label">TYPE of FICTC:</label>
                                    </div>
                                    <span class="error"><?php echo form_error('type');?></span>
                                </div>
                                
                                <div class="form-group form-float">
                                    <div class="form-line">
                                        <input type="text" class="form-control" name="pin" value="<?php if(isset($update)){ echo isset($update)?$update->pin:'';}else echo set_value('pin');?>" >
                                        <label class="form-label">Pincode :</label>
                                    </div>
                                     <span class="error"><?php echo form_error('pin');?></span>
                                </div>
                                <div class="form-group form-float">
                                    <div class="form-line">
                                        <input type="text" class="form-control" name="tal" value="<?php if(isset($update)){ echo isset($update)?$update->tal:'';}else echo set_value('tal');?>" >
                                        <label class="form-label">Taluka :</label>
                                    </div>
                                       <span class="error"><?php echo form_error('tal');?></span>
                                </div>
                                <div class="form-group form-float">
                                    <div class="form-line">
                                        <input type="text" class="form-control" name="dist" value="<?php if(isset($update)){ echo isset($update)?$update->dist:'';}else echo set_value('dist');?>">
                                        <label class="form-label">District : </label>
                                    </div>
                                    <span class="error"><?php echo form_error('dist');?></span>
                                </div>
                                <div class="form-group form-float">
                                    <div class="form-line">
                                        <input type="text" class="form-control" name="state" value="<?php if(isset($update)){ echo isset($update)?$update->state:'';}else echo set_value('state');?>" >
                                        <label class="form-label">State :</label>
                                    </div>
                                    <span class="error"><?php echo form_error('state');?></span>
                                </div>
                                <?php if($isedit) {  ?>
                                <input type="submit" class="btn btn-primary waves-effect" name="btnupdate" value="UPDATE">
                                 <?php } else { ?>
                                  <input type="submit" class="btn btn-success waves-effect" name="btnadd" value="Submit" >
                                  <?php } ?>
                                <button class="btn btn-secondary waves-effect" onclick=""  type="button">Cancel</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

         
        </div>

        <!-- #END# 
            Basic Validation -->

    </div>

</section>


