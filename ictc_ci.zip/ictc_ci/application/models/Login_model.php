<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Login_model extends CI_model {


    function __construct()
    {
      parent::__construct();
      date_default_timezone_set("Asia/Calcutta");
    }

    public function getdatabyid($id)
    {
      return $this->db->where('id',$id)->get('users')->row();
    }
  // save data of users
   public function register_user($data)
   {
      
      $pass = md5($this->input->post('password'));
      
      $data = array(
        
          'first_name'=>$_POST['first_name'],
           'last_name'=>$_POST['last_name'],
           'email'=>$_POST['email'],
           'password'=>$pass,
           'status'=>'Active',
           'createDate'=>date("Y-m-d h:i:s",time()),
           'updateDate'=>null,
       );
       
       $this->db->insert('users',$data);

   }
   
  // check login
   public function check_login($email,$pass)
   {
      // $q = $this->db->where(['email'=>$email,'password'=>$pass])
      //               ->get('users');

      $q = $this->db->where('email',$email)->where('password',$pass)->get('users');
      // echo "<pre>";print_r($q);exit;
        if($q->num_rows())
        {
          return $q->row();
        }
        else
        {
          return false;
        }
   } 
   // check email is exits..
   public function email_exits($email)
   {
      $e = $this->db->where(['email'=>$email,'status'=>'Active'])->get('users');
      if($e->num_rows())
        {
          return $e->row()->id;
        }
        else
        {
          return false;
        }
    }

   // store otp 
   public function otp($otp)
   {

      $data = array(
           'otp' =>$otp,
           'is_expire'=>1,
           'createDate'=>date("Y-m-d h:i:s",time()),
      );
      // print_r($data);exit;
      $isOtp = $this->db->insert('otp',$data);
       if($isOtp)
        {
          return true;
        }
        else
        {
          return false;
        }
   }

   // check otp
   public function otp_verify($otp_verify)
   {
     return $this->db->where('otp',$otp_verify)->get('otp')->row();                   
   }

   // update password
   public function confirm_password($new,$id)
   {
      return $this->db->where('id',$id)
                       ->set('password',md5($new))
                       ->update('users');

   }
}
?>