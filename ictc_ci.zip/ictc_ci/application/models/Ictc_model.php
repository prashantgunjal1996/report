<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Ictc_model extends CI_Model {

   
  function __construct()
  {
    parent::__construct();
    date_default_timezone_set("Asia/Calcutta");

  }

   public function get_center()
   {
    return $this->db->get('center')->result();
   }

   // get data by id
   public function get_center_by_id($id)
   {  
    return $this->db->where('id',$id)->get('center')->row();
   }

   // insert dataa
   public function post_center($data)
   {
        $data = array(
            'name' => $_POST['name'],
            'addr' => $_POST['addr'],
            'pin'  => $_POST['pin'],
            'tal'  => $_POST['tal'],
            'dist' => $_POST['dist'],
            'state'=> $_POST['state'],
            'ictc_type' => $_POST['type'],
            'Added_by' =>'s',
            'Status' =>'Active',
            'createDate' =>date("Y-m-d h:i:s",time()),
            'updateDate'=>null,
        );
        // echo"<pre>";print_r($data);exit;
         $this->db->insert('center',$data);
         return true;
   }

   // fetch data 
   public function put_center($data,$c_id)
   {  

        $data = array(

            'id' => $c_id,
            'name' =>$_POST['name'],
            'addr' =>$_POST['addr'],
            'pin' =>$_POST['pin'],
            'tal' =>$_POST['tal'],
            'dist' =>$_POST['dist'],
            'state' =>$_POST['state'],
            'ictc_type' =>$_POST['type'],
            'Added_by' =>'s',
            'Status' =>'Active',
            'createDate' =>date("Y-m-d h:i:s",time()),
            'updateDate'=>null,
        );
        // echo "<pre>";print_r($data);exit;
        return $this->db->where('id',$c_id)->update('center',$data);
        // return true;
   }

  public function center_delete($id)
  {
      $this->db->where("id",$id)->delete("center");
  }



  public function get_owner()
   {
    return $this->db->get('owner')->result();
   }

    public function get_info_by_id($id)
   {  
    return $this->db->where('id',$id)->get('owner')->row();
   }


   public function post_info($data)
   {
    $data = array(
            'name' =>$_POST['name'],
            'email' =>$_POST['email'],
            'mob' =>$_POST['mobile'],
            'loc' =>$_POST['location'],
            'createDate' =>date("Y-m-d h:i:s",time()),
            'updateDate'=>null,
        );
         // echo"<pre>";print_r($data);exit;
         $this->db->insert('owner',$data);
         return true;
   }

   public function put_info($data,$id)
   {
    $data = array(
            
            'id' => $id,
            'name' =>$_POST['name'],
            'email' =>$_POST['email'],
            'mob' =>$_POST['mobile'],
            'loc' =>$_POST['location'],
            'createDate' =>date("Y-m-d h:i:s",time()),
            'updateDate'=>null,
        );
        // echo"<pre>";print_r($data);exit;
        return $this->db->where('id',$id)->update('owner',$data);
         
   }

   public function info_delete($id)
  {
      $this->db->where("id",$id)->delete("owner");
  }

  public function get_owner_report()
   {
    return $this->db->get('owner')->row();
   }

   public function get_center_report()
   {
    return $this->db->get('center')->row();
   }

}
?>