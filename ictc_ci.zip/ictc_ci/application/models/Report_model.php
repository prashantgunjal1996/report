<?php


class Report_model extends CI_Model {


    function __construct()
    {
        parent::__construct();
        date_default_timezone_set("Asia/Calcutta");

    }
    
    // get record by id
    public function get_report()
    {
        return $this->db->get('progress_report')->result();
    }

    // get record by id
    public function get_report_by_id($id)
    {
        return $this->db->where('id',$id)->get('progress_report')->row();
    }

    public function last_record()
    {
        return $this->db->get('progress_report')->last_row();
        
    }

    public function post_report($data)
    {
        $data = array(

            'reporting_period' => $_POST['startDate'],
            'anc' => $_POST['anc'],
            'anc_detect' => $_POST['p_anc'],
            'male' => $_POST['male'],
            'male_detect' => $_POST['p_male'],
            'female' => $_POST['female'],
            'female_detect' => $_POST['p_female'],
            'male_female_total' => $_POST['total_mf'],
            'detected_mf_total' => $_POST['total_p_mf'],
            'batchno' => $_POST['batch'],
            'expirydate' => $_POST['exp_date'],
            'openingstock' => $_POST['opngstck'],
            'consumed' => $_POST['consumed'],
            'received' => $_POST['received'],
            'control' => $_POST['control'],
            'wastage' => $_POST['wastage'],
            'closing' => $_POST['closing'],
            'qty_intended' => $_POST['qty'],
            'status' => true,
            'createDate' =>date("Y-m-d h:i:s",time()),
            'updateDate'=>null,
           
        );
        // echo "<pre>";print_r($data);exit;
        return $this->db->insert('progress_report',$data);
    }

    public function put_report($data,$id)
    {
        $data = array(
            'id'=>$id,
            'reporting_period' => $_POST['startDate'],
            'anc' => $_POST['anc'],
            'anc_detect' => $_POST['p_anc'],
            'male' => $_POST['male'],
            'male_detect' => $_POST['p_male'],
            'female' => $_POST['female'],
            'female_detect' => $_POST['p_female'],
            'male_female_total' => $_POST['total_mf'],
            'detected_mf_total' => $_POST['total_p_mf'],
            'batchno' => $_POST['batch'],
            'expirydate' => $_POST['exp_date'],
            'openingstock' => $_POST['opngstck'],
            'consumed' => $_POST['consumed'],
            'received' => $_POST['received'],
            'control' => $_POST['control'],
            'wastage' => $_POST['wastage'],
            'closing' => $_POST['closing'],
            'qty_intended' => $_POST['qty'],
            'createDate' =>date("Y-m-d h:i:s",time()),
            'updateDate'=>null,
           
        );
        // echo "<pre>";print_r($data);exit;
        return $this->db->where('id',$id)->update('progress_report',$data);
    }

    public function delete($id)
    {
       return $this->db->where('id',$id)->delete('progress_report');
    }

}