<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ictc extends CI_Controller {

	
	function __construct() {
        parent::__construct();
        $this->load->model('Ictc_model');
        if(!$this->session->userdata('id'))
        {
            redirect('Login/');
        }
        
    }

    public function index() {
        $this->load->view('index');
	}
	
    public function manage($edit=0)
    {
        $isedit = $edit;
        if($isedit!=0)
        {
            $data['isedit'] = true;
            $data['update'] = $update = $this->Ictc_model->get_center_by_id($isedit);

            $data['id'] = $c_id = $isedit;
            $data['name'] =  $update->name;
            $data['addr'] = $update->addr;
            $data['pin'] = $update->pin;
            $data['tal'] =  $update->tal;
            $data['dist'] =  $update->dist;
            $data['state'] = $update->state;
            $data['ictc_type'] =  $update->ictc_type;
            // echo "<pre>";print_r($data);exit;
            $this->load->view('register',$data);
        }

        $data['records'] =  $this->Ictc_model->get_center();
        if($isedit==0)
        {
            $this->load->view('center_index',$data);
        }
    }

    public function add_center($c_id=0)
    {

        $data['id'] = $c_id;
        $data['isedit'] = $isedit = false;

        if($this->form_validation->run('add_center'))
        {
            if($this->input->post('btnadd'))
            {
                unset($_POST['btnadd']);
                $isAdd = $this->Ictc_model->post_center($_POST);
                if($isAdd)
                {
                    $this->session->set_flashdata('add_center','Successfully Added');
                    redirect('ictc/manage');
                }
                else
                {
                   $this->session->set_flashdata('Error','Error While Adding Center');
                     redirect('ictc/manage');
                    //redirect('login/');
                }
            }

            else
            {
                $isupdate_center  = $this->Ictc_model->put_center($_POST,$c_id);
                if($isupdate_center)
                {
                   $this->session->set_flashdata('update_center','a');
                   redirect('ictc/manage');
                }
                else
                {
                    $this->session->set_flashdata('update_error','a');
                }
                // redirect('ictc/manage');
            }
        }
        else
        {
             $this->load->view('register',$data);
        }
       
    }


    // delete center..
    public function center_delete($id)
    {
        $data['id']   =   $id;
        $isDelete   =   $this->Ictc_model->center_delete($id);
        if($isDelete)
        {
             $this->session->set_flashdata('delete','Record Delete Successfully');
        }
        redirect('ictc/manage');
    }

    // manage personal info
    public function info_manage($edit=0)
    {
        $isedit_info = $edit;
        $data['isedit_info'] = true;
        if($isedit_info!=0)
        {
            $data['update_info'] = $update_info = $this->Ictc_model->get_info_by_id($isedit_info);
            $data['id'] = $id = $isedit_info;
            $data['name'] =  $update_info->name;
            $data['email'] = $update_info->email;
            $data['mob'] = $update_info->mob;
            $data['loc'] =  $update_info->loc;
            // echo "<pre>" ; print_r($data);exit;
            $this->load->view('personal_info_add',$data);
        }

        $data['records'] =  $this->Ictc_model->get_owner();
        if($isedit_info==0)
        {
            $this->load->view('personal_info_index',$data);
        }
    }


    // add personal Info
    public function personal_info($id=0)
    {

        $data['id'] = $id;
        $data['isedit_info'] = $isedit_info = false;

        if($this->form_validation->run('personal_form'))
        {
            if($this->input->post('btnaddinfo'))
            {
                unset($_POST['btnaddinfo']);
                $isAdd  = $this->Ictc_model->post_info($_POST);
                // print_r($isAdd);exit;
                if($isAdd)
                {
                   $this->session->set_flashdata('added','a');
                   redirect('ictc/personal_info');
                }
                else
                {
                    $this->session->set_flashdata('error','a');
                }
                
            }
            else
            {
                $isupdate  = $this->Ictc_model->put_info($_POST,$id);
                if($isupdate)
                {
                   $this->session->set_flashdata('updated','a');
                   redirect('ictc/personal_info');
                }
                else
                {
                    $this->session->set_flashdata('update_error','a');
                }

                redirect('ictc/info_manage');
                // echo "Button submit in else part";
            }
           
        }
        else{
            $this->load->view('personal_info_add',$data);
        }
        

    }

    // delete owner..
    public function delete($id)
    {
        $data['id']   =   $id;
        $isDelete   =   $this->Ictc_model->info_delete($id);
        if($isDelete)
        {
             $this->session->set_flashdata('delete','Record Delete Successfully');
        }
        redirect('ictc/info_manage');
        
    }
    
    public function logout()
    {
        $this->session->unset_userdata('id');
        $this->session->sess_destroy();
        redirect('Login/');
    }
}
?>
       