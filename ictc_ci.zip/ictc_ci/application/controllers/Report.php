<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Report extends CI_Controller {

	
	function __construct()
	{
		parent::__construct();
		$this->load->model('Report_model');
		$this->load->model('Ictc_model');
		if(!$this->session->userdata('id'))
        {
            redirect('Login/');
        }
	}
	public function index()
	{
		$this->manage_report();
	}

	public function last()
	{
		$data['last_record'] = $last_record =  $this->Report_model->last_record();
		$data['openingstock'] = $last_record->openingstock;
		$data['expirydate'] =$last_record->expirydate;
		$data['batchno'] =$last_record->batchno;
	}

	public function manage_report($edit=0)
	{
		
		$isedit = $edit;
		if($isedit!=0)
		{
			$data['isedit'] = true;
			$data['update_report'] = $update_report = $this->Report_model->get_report_by_id($isedit);
			$data['id'] =  $update_report->id;
			$data['anc'] =  $update_report->anc;
			$data['reporting_period'] =  $update_report->reporting_period;
			$data['anc_detect'] = $update_report->anc_detect;
            $data['male'] = $update_report->male;
            $data['male_detect'] = $update_report->male_detect;
            $data['female'] = $update_report->female;
            $data['female_detect'] = $update_report->female_detect;
            $data['male_female_total'] = $update_report->male_female_total;
            $data['detected_mf_total'] = $update_report->detected_mf_total;
            $data['batchno'] = $update_report->batchno;
            $data['expirydate'] = $update_report->expirydate;
            $data['openingstock'] = $update_report->openingstock;
            $data['consumed'] = $update_report->consumed;
            $data['received']= $update_report->received;
            $data['control'] = $update_report->control;
            $data['wastage'] = $update_report->wastage;
            $data['closing'] = $update_report->closing;
            $data['qty_intended'] = $update_report->qty_intended;
			$this->load->view('generate_report',$data);
		}
		
		$data['reports'] = $this->Report_model->get_report();
		
	
		if($isedit==0)
		{
			$this->load->view('report_index',$data);
		}
		

	}

	public function generate_report($r_id=0)
	{
		$data['id']  = $r_id;
		$data['isedit']  = false;

		$data['last_record'] = $last_record =  $this->Report_model->last_record();
		$data['batchno'] = $last_record->batchno;
        $data['expirydate'] = $last_record->expirydate;
        $data['openingstock'] = $last_record->closing;
        

		if($this->form_validation->run('progress_form'))
		{
			if($this->input->post('btnreport'))
			{


				$isReport = $this->Report_model->post_report($_POST);
				if($isReport)
                {
                   $this->session->set_flashdata('report_success','a');
                   redirect('Report/manage_report');
                }
                else
                {
                    $this->session->set_flashdata('report_fail','a');
                     redirect('Report/manage_report');
                }
			}
			else
			{
				$isupdate_report  = $this->Report_model->put_report($_POST,$r_id);
				// echo $isupdate_report;exit;
                if($isupdate_report)
                {
                   $this->session->set_flashdata('update_report','a');
                   redirect('Report/manage_report');
                }
                else
                {
                    $this->session->set_flashdata('update_error','a');
                }
			}
		}
		$this->load->view('generate_report',$data);
	}

	public function delete_report($id)
	{
		$data['id']   =   $id;
		$isDelete = $this->Report_model->delete($id);
		if($isDelete)
		{
			$this->session->set_flashdata('delete_report','a');
			redirect('Report/manage_report');
		}
	}


	public function view($id)
	{
		$data['id']   =   $id;
		// get center by id
		$info = $this->Ictc_model->get_owner_report();
		
		$data['name'] = $info->name;
		$data['email'] = $info->email;
		$data['mob'] = $info->mob;
		$data['loc'] = $info->loc;
		
		
		$data['center'] = $center = $this->Ictc_model->get_center_report();
		//$data['name'] =  $center->name;
		// $data['addr'] = $center->addr;
		// $data['pin'] = $center->pin;
		// $data['tal'] =  $center->tal;
		// $data['dist'] =  $center->dist;
		// $data['state'] = $center->state;
		// $data['ictc_type'] =  $center->ictc_type;
		
		
		// get report
		$data['view'] = $view = $this->Report_model->get_report_by_id($id);
		$data['anc'] =  $view->anc;
		$data['reporting_period'] =  $view->reporting_period;
		$data['anc_detect'] = $view->anc_detect;
		$data['male'] =  $view->male;
        $data['male_detect'] =  $view->male_detect;
        $data['female'] =  $view->female;
        $data['female_detect'] =  $view->female_detect;
        $data['male_female_total'] =  $view->male_female_total;
        $data['detected_mf_total'] =  $view->detected_mf_total;
        $data['batchno'] =  $view->batchno;
        $data['expirydate'] =  $view->expirydate;
        $data['openingstock'] =  $view->openingstock;
        $data['consumed'] =  $view->consumed;
        $data['received']=  $view->received;
        $data['control'] =  $view->control;
        $data['wastage'] =  $view->wastage;
        $data['closing'] =  $view->closing;
        $data['qty_intended'] =  $view->qty_intended;
		
		$this->load->view('report_view',$data);
	}
}
?>