<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

    
    function __construct()
    {
        parent::__construct();
        $this->load->model('Login_model');
        if($this->session->userdata('id'))
        {
            redirect('ictc/');
        }

        
    }
    public function index() {
        $this->isLogin();
    }


    // login
    public function isLogin()
    {
        if($this->form_validation->run('login_form'))
        {
            $email = $this->input->post('username');
            $pass = md5($this->input->post('password'));
            $login_data = $this->Login_model->check_login($email,$pass);

            if($login_data)
            {
                $data = array(
                    'id'=> $login_data->id,
                    'email' =>$login_data->email,
                    'firstname'=>$login_data->first_name,
                );

                $this->session->set_userdata($data);
                redirect('ictc/');
            }
            else
            {
                $this->session->set_flashdata('error','Enter valid user name and password');
            }
        }
        $this->load->view('signin');
    }

    // create users
    public function isRegister()
    {
        if($this->form_validation->run('signup_form'))
        {
            if($this->input->post('btnsignup'))
            {
                unset($_POST['btnsignup']);
                $isAdd = $this->Login_model->register_user($_POST);
                if($isAdd)
                {
                    $this->session->set_flashdata('added','Successfully Added');
                }
                else
                {
                    redirect('login/');
                }
            }
        }
        $this->load->view('signup');
    }

    // send mail with otp
    public function email($data = '')
    {
        $this->load->library('email');
        $otp = rand(100000, 999999);
        $onepass = $this->Login_model->otp($otp);
        if($onepass)
        {
            $email = $data['email'] ;
            $to_email = $email;
            $subject = "";
            $body = "Please enter the below otp to reset password Your Otp is ".$otp;
            $headers = "From: profitablegrowth.04@gmail.com";
            if (mail($to_email, $subject, $body, $headers)) {
                    echo "<script>alert('OTP sent to your mail');</script>";
                    
            } else {
                echo "<script>alert('Failed to send mail');</script>";
                redirect('Login/resetpassword');
            }
            
        }
        else{
            redirect('Login/');
        }
        
    }

    // check mail is exits and send mail
    public function resetpassword()
    {
        if($this->form_validation->run('check_email'))
        {
            $data['email'] = $email = $this->input->post('email');
            $isemail = $this->Login_model->email_exits($email);
            
            if($isemail)
            {
                // print_r($isemail);exit;
                $this->session->set_flashdata('success','a');
                $this->email($data);
            }
            else{
                $this->session->set_flashdata('error','Please enter a valid email');
            }
        }
        $this->load->view('forgot');
    }


    public function otp_verification()
    {
       $this->load->model('Login_model');
       if($_POST['otp']=="")
       {
            $this->session->set_flashdata('success','a');
            $this->session->set_flashdata('otp_error','Please Enter OTP');
            redirect('Login/resetpassword');
       }
       else
        {
            if($this->input->post('btnotp'))
            {
                $data['otp_verify'] = $otp_verify = $this->input->post('otp');
                $isVerify  = $this->Login_model->otp_verify($otp_verify);
                // print_r($isVerify);exit;
                if($isVerify)
                {
                    $this->session->set_flashdata('success','a');
                    $this->session->set_flashdata('match','a');
                    redirect('Login/new_password');   
                }
                else{
                  
                    $this->session->set_flashdata('success','a');
                    $this->session->set_flashdata('unverify','c');
                    // echo "<script>alert('OTP not match');</script>";
                    redirect('Login/resetpassword');
                    
                }
            }
        }
     }

    public function new_password($email=0)
    {   
        $isemail = $this->Login_model->email_exits($email);
        if($this->form_validation->run('reset_form'))
        {
            if($this->input->post('btnnewpass'))
            {
                $newpass = $this->input->post('newpass');
                $cnfmpass = $this->input->post('cnfmpass');
                if($newpass == $cnfmpass)
                {
                    $isConfirm = $this->Login_model->confirm_password($cnfmpass,$isemail);
                    if(!empty($isConfirm))
                    {
                        $this->session->set_flashdata('change','c');
                        //redirect('Login/');
                    }   
                    else{
                        echo "<script>alert('Error While Creating new password');</script>";
                    }
                }
                else{
                     echo "<script>alert('Your password did not match');</script>";
                }
            }
        }
        else
        {
           //redirect('login/new_password');
        }
        $this->load->view('resetpassword');
        
    }

    
}
?>