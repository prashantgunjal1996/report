<?php
	$config = 
	[

			// 
			'signup_form' =>
			[
				[
				'field' => 'first_name',
				'label' => 'First Name',
				'rules'  => 'required'
				],
				[
				'field' => 'last_name',
				'label' => 'Last Name',
				'rules'  => 'required'
				],
				[
				'field' => 'email',
				'label' => 'Email',
				'rules'  => 'required'
				],
				[
				'field' => 'password',
				'label' => 'Password',
				'rules'  => 'required'
				]
			],

			// 

			'login_form' =>
			[
				[
				'field' => 'username',
				'label' => 'Email',
				'rules'  => 'required'
				],
				[
				'field' => 'password',
				'label' => 'Password',
				'rules'  => 'required'
				],
			],

// 
			'check_email' =>
			[
				[
				'field' => 'email',
				'label' => 'Email',
				'rules'  => 'required'
				],
				
			],


			'check_otp' =>
			[
				[
				'field' => 'otp',
				'label' => 'OTP',
				'rules'  => 'required'
				],
				
			],


			// add center form
			'add_center' =>
			[
				[
				'field' => 'name',
				'label' => 'Center Name',
				'rules'  => 'required'
				],

				[
				'field' => 'addr',
				'label' => 'Center Addresse',
				'rules'  => 'required'
				],
				[
				'field' => 'type',
				'label' => 'Type of Center',
				'rules'  => 'required'
				],

				[
				'field' => 'pin',
				'label' => 'Pincode',
				'rules'  => 'required'
				],

				[
				'field' => 'tal',
				'label' => 'Taluka',
				'rules'  => 'required'
				],

				[
				'field' => 'dist',
				'label' => 'District',
				'rules'  => 'required'
				],

				[
				'field' => 'state',
				'label' => 'State',
				'rules'  => 'required'
				],
			],

			// password reset form
			'reset_form' =>
			[
				[
				'field' => 'newpass',
				'label' => 'New Password',
				'rules'  => 'required'
				],
				[
				'field' => 'cnfmpass',
				'label' => 'Confirm Password',
				'rules'  => 'required'
				],
			],

			// owner form
			'personal_form' =>
			[
				[
				'field' => 'name',
				'label' => 'Owner Name',
				'rules'  => 'required'
				],
				[
				'field' => 'mobile',
				'label' => 'Mobile',
				'rules'  => 'required'
				],
				[
				'field' => 'email',
				'label' => 'Email',
				'rules'  => 'required'
				],
				[
				'field' => 'location',
				'label' => 'ICTC Location',
				'rules'  => 'required'
				],
			],


			// owner form
			'progress_form' =>
			[
				[
				'field' => 'anc',
				'label' => 'ANC',
				'rules'  => 'required'
				],
				[
				'field' => 'male',
				'label' => 'Male',
				'rules'  => 'required'
				],
				[
				'field' => 'female',
				'label' => 'Female',
				'rules'  => 'required'
				],
				[
				'field' => 'p_anc',
				'label' => 'Detected ANC',
				'rules'  => 'required'
				],

				[
				'field' => 'p_male',
				'label' => 'Detected Male',
				'rules'  => 'required'
				],

				[
				'field' => 'p_female',
				'label' => 'Detected Female',
				'rules'  => 'required'
				],

				[
				'field' => 'total_p_mf',
				'label' => 'Total Positive',
				'rules'  => 'required'
				],
				[
				'field' => 'total_mf',
				'label' => 'Total Male & Female',
				'rules'  => 'required'
				],
				
			],




	];
?>